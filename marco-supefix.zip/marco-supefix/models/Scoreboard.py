import pygame


class Scoreboard(pygame.sprite.Sprite):
    # Constructor
    def __init__(self, x, y):
        super().__init__()